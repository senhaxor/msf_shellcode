# Bypass_AV
通过映射注入来躲避杀毒软件对系统常用关键API的挂钩查杀增加了隐蔽性，项目包含异或加密xor部分和loader部分语言由c++完成，使用该工具造成任何不良后果与作者无关，禁止用于非法活动。


上线正常：
![图片](https://user-images.githubusercontent.com/83112602/172034365-f2cad5b2-ca28-4f21-9d4a-6fe4c49f2dc6.png)

360

![图片](https://user-images.githubusercontent.com/83112602/172033663-1c5b0205-5dce-4645-8c78-125154f901f1.png)

火绒：

![图片](https://user-images.githubusercontent.com/83112602/172033692-c3148bb1-ae48-421d-8171-fb1812aae26d.png)

defender：

![图片](https://user-images.githubusercontent.com/83112602/172033715-00b89023-7e97-466f-880d-a14bfc648280.png)
